package parser;

public enum Category {
	NaverTVcast, YouTube, PandoraTV, 
	NaverNews, 
	NaverBlog, 
	GoogleImage, 
	ElevenST, Aution, Timon, Coupang,
	GitHub, StackOverFlow,
	NatePann, NaverKin,
	Wikipedia
}
